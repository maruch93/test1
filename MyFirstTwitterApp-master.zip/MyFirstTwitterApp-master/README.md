My First Twitter App
---


Ever wanted to create your own Twitter App? This simple script could help you!

For more information, see my in depth tutorial:
http://iag.me/socialmedia/build-your-first-twitter-app-using-php-in-8-easy-steps/